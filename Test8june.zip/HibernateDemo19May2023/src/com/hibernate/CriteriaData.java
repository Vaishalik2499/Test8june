package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.internal.CriteriaImpl;

public class CriteriaData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(StudentData.class).configure();
		
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ss= sf.openSession();
		
		Criteria crr=ss.createCriteria(StudentData.class);
		List<StudentData>list=crr.list();
		
		for(StudentData s:list) {
			System.out.println(s);
		}
				

	}

}
