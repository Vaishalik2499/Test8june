package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(StudentData.class).configure();
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss= sf.openSession();
		
		Transaction tx= ss.beginTransaction();
		
		StudentData s= new StudentData(1,"Vaishali");
		
		ss.update(s);
		System.out.println("Record Updated");
		tx.commit();
		ss.close();

	}

}
