package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(StudentData.class).configure();
		
		SessionFactory sf= cfg.buildSessionFactory();
		Session ss=sf.openSession();
		
		Transaction tx=ss.beginTransaction();
		 
		StudentData s=new StudentData(4,"VaishaliKolhe");
		ss.save(s);
		System.out.println("Contain saved");
		tx.commit();
		ss.close();

	}

}
