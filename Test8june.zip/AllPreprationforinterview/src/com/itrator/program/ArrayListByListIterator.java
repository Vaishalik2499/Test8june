package com.itrator.program;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListByListIterator {

	public static void main(String[] args) {
		ArrayList<String>al=new ArrayList<String>();
		al.add("Vaishali");
		al.add("Manisha");
		al.add("Aaradhya");
		
		
		ListIterator<String>itr=al.listIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
