package com.itrator.program;

import java.util.HashMap;
import java.util.Iterator;

public class Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String>hm=new HashMap<Integer, String>();
		hm.put(1, "AA");
		hm.put(2, "BB");
		hm.put(3, "CC");
		
		Iterator<Integer>itr=hm.keySet().iterator();
		while(itr.hasNext()) {
			int key=(int)itr.next();
			System.out.println(key +" "+hm.get(key));
		}

	}

}
