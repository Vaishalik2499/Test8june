package com.itrator.program;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListByIterator {

	public static void main(String[] args) {
	
		ArrayList<String>al=new ArrayList<String>();
		al.add("Vaishali");
		al.add("Kisan");
		al.add("Kolhe");
		
		Iterator itr=al.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
	}

}
