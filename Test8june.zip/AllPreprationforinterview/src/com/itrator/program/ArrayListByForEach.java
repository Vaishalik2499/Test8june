package com.itrator.program;

import java.util.ArrayList;

public class ArrayListByForEach {

	public static void main(String[] args) {
		ArrayList<String>al=new ArrayList<String>();
		al.add("Vaishali");
		al.add("Kolhe");
		
		for (String string : al) {
			System.out.println(string);
			
		}

	}

}
