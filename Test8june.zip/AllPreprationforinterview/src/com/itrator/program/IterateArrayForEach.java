package com.itrator.program;

public class IterateArrayForEach {

	public static void main(String[] args) {
		int a[]= {10,20,30,40};
		for (int i : a) {
			System.out.println(i);
			
		}
		System.out.println("****************************************");
		
		int arr[]=new int[4];
		arr[0]=100;
		arr[1]=200;
		arr[2]=300;
		arr[3]=400;
		for(int ir:arr) {
			System.out.println(ir);
			
		}

	}

}
