package com.itrator.program;

import java.util.HashMap;
import java.util.Iterator;

public class HashmapIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String>hm=new HashMap<Integer, String>();
		hm.put(6, "moni");
		hm.put(5, "Vaishali");
		
		Iterator<Integer>itr=hm.keySet().iterator();
		
		while(itr.hasNext()) {
			int key=(int) itr.next();
			System.out.println(key +" "+hm.get(key));
		}


		
		
	}

}
