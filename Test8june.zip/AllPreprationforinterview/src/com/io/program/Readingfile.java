package com.io.program;





import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Readingfile {

	public static void main(String[] args)throws IOException,FileNotFoundException {
		// TODO Auto-generated method stub
		FileReader fr=new FileReader("data.txt");
		int i;
		while((i=fr.read())!=-1) {
			System.out.println((char)i);
			fr.close();
		}

	}

}
