package com.logical;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,30,40,50};
		for(int i=a.length-1;i>=0;i--) {
			System.out.println(a[i]);
		}

	}

}
