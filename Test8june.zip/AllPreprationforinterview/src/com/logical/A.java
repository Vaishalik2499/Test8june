package com.logical;

import java.util.ArrayList;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int[] arr = {2, 4, 9, 16, 25, 36,81};
	        ArrayList<Integer> result = new ArrayList<Integer>();

	        for (int i = 0; i < arr.length; i++) {
	            double sqrt = Math.sqrt(arr[i]);
	            if (sqrt == (int) sqrt) {
	                result.add(arr[i]);
	            }
	        }

	        System.out.println("Elements with square roots:");
	        for (int i : result) {
	            System.out.println(i);

	}

}}
