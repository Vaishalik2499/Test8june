package com.logical;

import java.util.Scanner;

public class Squareroot {
	
	// Driver code
	public static void main (String[] args)
	{
		 Double num =4.0;
	        
	 
	      
	         
	        Double square = num*num;
	        System.out.println("Square of "+ num + " is: "+ square);
	    }
	}
	
	 

	