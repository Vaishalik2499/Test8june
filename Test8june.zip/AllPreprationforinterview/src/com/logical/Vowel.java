package com.logical;

public class Vowel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hello My Name is Vaishali.";
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u') {

			System.out.println("String Contain="+s.charAt(i) +" at the index="+i );
		}

	}

}
}