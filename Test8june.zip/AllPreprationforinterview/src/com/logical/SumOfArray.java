package com.logical;

public class SumOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,5,10,20};
		int sum=0;
		for (int i = 0; i < a.length; i++) {
			sum=sum+a[i];
			
		}
		System.out.println("sum="+sum);
	}

}
