package com.logical;

public class SquareRootOfArray {
	public static double[] square (double [] array) {
		  double[] result = new double[array.length];
		  for(int i = 0; i < array.length ; i++ )
		    result[i] = Math.sqrt(array[i]);

		  return result;
		}

	public static void main ( String args[] )
	{ 
	  double[] n  = {90,4,16,64,9,5,81,25,8};
	  double[] squ = square(n);

	  for(int i = 0; i < n.length ; i++ )
	    System.out.println ("Square root=" + n[i] + " is " + squ[i]);
	  
	  
	}

}
