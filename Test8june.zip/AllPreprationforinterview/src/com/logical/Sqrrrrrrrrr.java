package com.logical;


import java.util.Arrays;

public class Sqrrrrrrrrr {

		public static void main(String[] args) {
	        double[] arr = { 16, 25, 36, 49, 64 };
	        
	        // Calculate the square root of each element in the array
	        for (int i = 0; i < arr.length; i++) {
	            arr[i] = Math.sqrt(arr[i]);
	        }
	        
	        // Print the updated array
	        System.out.println(Arrays.toString(arr));
	    }
	}


