package com.logical;

public class Swapping2numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		System.out.println("berfore swapping "+a +" "+ b);
		int temp=a;
		a=b;
		b=temp;
		System.out.println("After swapping "+a +" "+ b);

	}

}
