package com.logical;

public class SwappingWithoutVariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=52;
		int b=69;
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		
		
		System.out.println(a +" "+b);

	}

}
