package com.logical;

public class Pyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row=5 ,number=1;
		for (int i = 1; i <=row; i++) {
			for (int j = 1; j <=i; j++) {
				System.out.print(number+" ");
				++number;
				
			}
			System.out.println();
			
		}

	}

}
