package com.logical;

public class RemoverWhiteSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Vaishali Kisan Kolhe";
		//System.out.println(s);
		s=s.replaceAll(" ", "");
		System.out.println(s);

	}

}
