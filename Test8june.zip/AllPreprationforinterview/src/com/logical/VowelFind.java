package com.logical;

public class VowelFind {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello Welcome To pune";
		for (int i = 0; i < s.length(); i++) {
			
			if(s.charAt(i)=='a'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u'||s.charAt(i)=='e') {
			System.out.println("String contain="+s.charAt(i) +" index "+i);
			
		}

	}

}
}