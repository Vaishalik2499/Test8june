package com.logical;

public class OddevenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,12,2,3,8,9,4};
		for (int i = 0; i < a.length; i++) {
			if(a[i]%2==0) {
				System.out.println("Even number" +a[i]);
			}
			
			
		}
		for (int i = 0; i < a.length; i++) {
		if(a[i]%2!=0) {
			System.out.println("Odd Number"+a[i]);
		}
		}
	}

}
