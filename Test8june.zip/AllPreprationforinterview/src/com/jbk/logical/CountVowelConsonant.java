package com.jbk.logical;

public class CountVowelConsonant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int vcount=0, ccount=0;
		
		String s="My Name is Vaishali";
		s=s.toLowerCase();
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u') {
				vcount++;
			
			}
			else if(s.charAt(i)>='a'&& s.charAt(i)<='z') {
				ccount++;
				
			}
			
		}
		System.out.println("Vowel Count="+ vcount);
		System.out.println("Consonant Count="+ ccount);

	}

}
