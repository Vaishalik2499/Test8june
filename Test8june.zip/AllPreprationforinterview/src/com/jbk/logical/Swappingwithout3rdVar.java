package com.jbk.logical;

public class Swappingwithout3rdVar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=40;
		int b=50;
		a=a+b;//90
		b=a-b;//90-50=40
		a=a-b;//90-40=50
		System.out.println(a +" "+b);

	}

}
