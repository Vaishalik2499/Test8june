package com.jbk.logical;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=54321;
		int rev;
		int sum=0;
		while(n>0) {
			rev=n%10;
			sum=(sum*10)+rev;
			n=n/10;
		}
		System.out.print(sum);
		

	}

}
