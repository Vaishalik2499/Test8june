package com.jbk.logical;

public class PalindromeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n=323;
		int temp=n, sum=0;
		while(n>0) {
			int v=n%10;
			sum=(sum*10)+v;
			n=n/10;
			
		}
		if(temp==sum) {
		System.out.println("PalindromeNumber");
			
		}
		else
			System.out.println("Not PalindromeNumber");
	}

}
