package com.jbk.logical;

public class Vowel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Mynameisvaishali";
		
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)=='a'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u'||s.charAt(i)=='e') {
				System.out.println("String ContainsVowel  = "+s.charAt(i) +  "  Index "+i);
				
			}
			else
				System.out.println("consonants= "+s.charAt(i));
			
		}

	}

}
