package com.jbk.logical;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Vaishali Kisan Kolhe";
		for (int i = s.length()-1; i>=0; i--) {
			System.out.print(s.charAt(i));
			
		}
		

	}

}
