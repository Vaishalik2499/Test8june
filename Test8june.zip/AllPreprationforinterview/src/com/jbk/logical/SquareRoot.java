package com.jbk.logical;


import java.util.Arrays;

public class SquareRoot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a[]= {16,25,81,64,25};
		
		for (int i = 0; i < a.length; i++) {
			a[i]=Math.sqrt(a[i]);
			
			
		}
		System.out.println(Arrays.toString(a));

	}

}
