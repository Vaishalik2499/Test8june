package com.jbk.logical;

public class RemoveSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Vaishali Kolhe";
		s=s.replaceAll(" ", "");
		System.out.print(s);

	}

}
