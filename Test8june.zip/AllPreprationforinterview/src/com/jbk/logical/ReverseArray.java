package com.jbk.logical;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {11,22,3,4};
		
		for (int i = a.length-1; i >= 0; i--) {
			System.out.println(a[i]);
			
		}
		

	}

}
