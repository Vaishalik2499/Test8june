package com.jbk.logical;

public class OddEvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=11;
		if(n%2==0) {
			System.out.println("Even Number");
		}
		else 

			System.out.println("odd Number");
	   

	}

}
