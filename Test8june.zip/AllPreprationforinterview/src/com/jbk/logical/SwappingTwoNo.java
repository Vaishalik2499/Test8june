package com.jbk.logical;

public class SwappingTwoNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=45;
		int b=95;
		System.out.println("BeforSwapping="+a +" "+b);
		int temp=a;
		a=b;
		b=temp;
		System.out.println("After Swapping="+a +" "+b);
		

	}

}
