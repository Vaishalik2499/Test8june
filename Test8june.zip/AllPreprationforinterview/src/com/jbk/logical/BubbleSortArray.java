package com.jbk.logical;

public class BubbleSortArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {5,1,8,2,9,3,7};
		int temp;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
					
				}
				
			}
			
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
			
		}
		System.out.println("Higest Number="+a[a.length-1]);

	}

}
