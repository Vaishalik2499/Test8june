package com.jbk.lagiccal;

public class Pattern1to15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=1;
		int row=5;
		for(int i=1;i<=row;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(number+" ");
				++number;
			}
			System.out.println();
		}

	}

}
