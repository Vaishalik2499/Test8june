package com.jbk.lagiccal;

public class FindOddEvennumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,4,5,7,8,2};
		
		for (int i =0; i < a.length; i++) {
			if(a[i]%2==0) {
				System.out.println("Even numbers" +a[i]);
			}
			
			
		}
		
		for (int i =0; i < a.length; i++) {
			if(a[i]%2!=0) {
				System.out.println("Odd numbers" +a[i]);
			}
			
			
		}
		
		

	}

}
