package com.jbk.lagiccal;

import java.util.Scanner;

public class VowelConsonant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Character");

		char ch=sc.next( ).charAt(0);
		//char ch='i';
		if(ch=='a'||ch=='o'||ch=='u'||ch=='e'||ch=='i') {
			System.out.println(ch +" Is Vowel");
		}
		else
			System.out.println(ch +" Is Consonant");
		}                                                                            
}

