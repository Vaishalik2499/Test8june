package com.jbk.lagiccal;

public class SwapingWithoutThird {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=30;
		int b=20;
		
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println(a + " "+ b);
		

	}

}
