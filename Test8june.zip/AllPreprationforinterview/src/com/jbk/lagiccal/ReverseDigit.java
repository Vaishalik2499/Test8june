package com.jbk.lagiccal;

public class ReverseDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=123;
		int rev;
		while(n>0) {
			rev=n%10;
			System.out.print(rev);
			n=n/10;
		}

	}

}
