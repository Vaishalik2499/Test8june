package com.jbk.lagiccal;

public class Square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

        String s="Hello planet earth,you are a great planet.";
        System.out.println(s.lastIndexOf("planet"));
        

	}

}
