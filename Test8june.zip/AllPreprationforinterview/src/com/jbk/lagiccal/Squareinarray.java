package com.jbk.lagiccal;

import java.util.Arrays;

public class Squareinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a[]= {25,36,64,81,16};
		
		for (int i = 0; i < a.length; i++) {
			a[i]=Math.sqrt(a[i]);
			
			
		}
		System.out.println(Arrays.toString(a));
	}

}
