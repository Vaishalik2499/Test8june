package com.practice.logical;

public class FindOddPositionArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,11,12,13,14,15};
		int count=0;
		for (int i = 1; i < a.length; i=i+2) {
			if(a[i]%2==0) {
				count++;
				break;
			}
			System.out.println(a[i]);
			
		}
		
	}

}
