package com.practice.logical;

public class Phone {
	int cost;

	public Phone(int cost) {
		super();
		this.cost = cost;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Phone [cost=" + cost + "]";
	}
	

}
