package com.practice.logical;

public class Emp {
	 int age;
	 int salary;
	 String add;
	 Phone ph;
	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Emp(int age, int salary, String add) {
		super();
		this.age = age;
		this.salary = salary;
		this.add = add;
	}
	public Emp(int age, int salary, String add, Phone ph) {
		super();
		this.age = age;
		this.salary = salary;
		this.add = add;
		this.ph = ph;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	@Override
	public String toString() {
		return "Emp [age=" + age + ", salary=" + salary + ", add=" + add + "]";
	}
	 
	 

}
