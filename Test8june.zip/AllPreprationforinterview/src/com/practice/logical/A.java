package com.practice.logical;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {4,7,9,2,4,7,8,8,88,1};
		int temp;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
				
			}
			
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
			
		}

	}

}
