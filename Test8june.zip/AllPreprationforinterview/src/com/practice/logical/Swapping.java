package com.practice.logical;

public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=10;
		int b=20;
		int temp=a;
		a=b;
		b=temp;
		System.out.println(a+" "+b);

	}

}
