package com.practice.logical;


// Arraylist 
//Emp age,salary.add  // We need to filter emp with age more than 30 & Phone cost more than 20k

import java.util.Arrays;

import java.util.List;

import java.util.stream.Collectors;

public class EmpMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp>al=Arrays.asList(new Emp (22,50000,"pp",new Phone(2000)),new Emp(35,50000,"ss",new Phone(12000)),new Emp(20,50000,"vv",new Phone(22000)));
		
		System.out.println(al.stream().filter(e -> e.age>30).collect(Collectors.toList()));
		
		System.out.println(al.stream().filter(e->e.ph.cost>20000).collect(Collectors.toList()));
		
		
		

	}

}
