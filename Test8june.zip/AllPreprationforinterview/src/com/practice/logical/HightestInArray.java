package com.practice.logical;

public class HightestInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {8,15,2,3,45,6,0};
		int temp;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
				
			}
			
		}
		System.out.println("Highest Number= "+a[(a.length-1)]);
		System.out.println("2nd Highest Number="+a[(a.length-2)]);
		System.out.println("Lowest Number= "+a[0]);
		

	}

}
