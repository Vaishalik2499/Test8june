package com.practice.logical;

public class FindEvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	int a[]= {15,13,16,4,8,100};
	for (int i = 0; i < a.length; i++) {
		if(a[i]%2==0) {
			System.out.print("EvenNumber= "+a[i]);
		}
		else
			System.out.println("OddNumber= "+a[i]);
		
		
	}
	
	
	}

}
