package com.jbk.jdbcpractice;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SimpleJdbc {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		Statement stmt=con.createStatement();
		System.out.println("Connected");
		//int result=stmt.executeUpdate("insert into customer values(101,'Nashik' , 'Jay')");
		//int result=stmt.executeUpdate("update customer set name='Kajal' where id=6");
		//int result=stmt.executeUpdate("delete from customer where id=100");
		
		String str="select * from customer ";
		
		ResultSet rs=stmt.executeQuery(str);
		while(rs.next()) {
			
			System.out.println(rs.getInt(1) +" "+ rs.getString(2) +" " + rs.getString(3));
		}

		

	}

}
