package SprinBootMVC.Project29March.demo.SpringBootWithHibernate;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;



public class Controller {
	
     @Autowired
	SessionFactory sf;
     @RequestMapping("/")
 	public String loginpage() {
 		return "login";
 	}
     @RequestMapping("/login")
 	public String login(@ModelAttribute Login login, Model model) {
 		Session session=sf.openSession();
 		
 		Login dblogin=session.get(Login.class, login.getUsername());
 		String page="login";
 		String msg=null;
 		  if(dblogin !=null) {
 			if(login.getPassword().equals(dblogin.getPassword())) {
 				page="home";
 			}else {
 				msg="invalid password";
 			}
 			}
 		else {
 			msg="invalid username and password";
 		}
 		model.addAttribute("msg", msg);
 		return page;
 	}
     
     
     
     }


