package SprinBootMVC.Project29March.demo.SpringBootWithHibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringBootWithHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootWithHibernateApplication.class, args);
		System.err.println("Spring Running");
	}

}
