package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(Connector.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		
		Transaction tx=ss.beginTransaction();
		
		//Connector c=new Connector(12,"ShyamDeshmukh");
		Connector c1=new Connector(12,"Shyam");
		
		//ss.save(c1);
		//ss.update(c);
		//ss.delete(c1);
		ss.saveOrUpdate(c1);
		System.out.println("Recored inserted");
		tx.commit();
		ss.close();

	}

}
