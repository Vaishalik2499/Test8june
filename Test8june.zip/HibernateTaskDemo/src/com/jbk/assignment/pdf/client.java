package com.jbk.assignment.pdf;
// perform save,update,delete operation.....
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(Student01.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		
		Transaction tx=ss.beginTransaction();
		
		//Student01 stud=new Student01(01 ,"Vaishali","Pune","vaishali@07");
		//ss.save(stud);
		/*Student01 stud=new Student01();
		stud.setId(2);
		stud.setName("Monika");
		stud.setAddress("Delhi");
		stud.setEmail("monika98@gmail.com");
		
		ss.saveOrUpdate(stud);*/
		//Student01 stud=new Student01(01 ,"Vaishali","Shegaon","vaishali@07");
		//ss.update(stud);
		//Student01 stud=new Student01(01 ,"Vaishali","shegaon","vaishali@07");
		//ss.delete(stud);
		tx.commit();
		ss.close();
		System.out.println("Data  Deleted Successfully");
		
		
		
		
		
		
		

	}

}
