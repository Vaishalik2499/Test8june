package com.jbk.hibernate.practice;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestFaculty {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(Faculty.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		
		Transaction tx=ss.beginTransaction();
		
		Faculty f=new Faculty(1201,"Riya","riya@123.gamil.com","Pune");
		ss.save(f);
		tx.commit();
		System.out.println(f);
		
		

	}

}
