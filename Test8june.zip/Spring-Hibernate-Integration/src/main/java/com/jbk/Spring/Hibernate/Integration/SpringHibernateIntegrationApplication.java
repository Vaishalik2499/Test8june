package com.jbk.Spring.Hibernate.Integration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHibernateIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHibernateIntegrationApplication.class, args);
		System.out.println("Spring Running");
	}

}
