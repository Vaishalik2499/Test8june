package com.jbk.Spring.Hibernate.Integration;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class StudentController {
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("showSingleRecord")
	public Student showSingledata() {
		
		Session ss=sf.openSession();
		Student s=ss.load(Student.class, 101);
		System.out.println(s);
		return s;
		
	}
	@GetMapping("showmultipleRecord")
	public List showMultipleData() {
		Session ss=sf.openSession();
		String hql="from Student";
		Query query=ss.createQuery(hql);
		List result=query.list();
		
		System.out.println(result);
		return result;
	}
	@PostMapping("InsertRecord")
public	Student inserRecord() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Student s=new Student(299,"Shyam");
		ss.save(s); 
		tx.commit();
		System.out.println(s);
		return s;
	}
	@PutMapping("updateRecord")
 public Student updateRecord(){
		Session ss= sf.openSession();
		Transaction tx=ss.beginTransaction();
		Student s=new Student(99,"Vansh");
		ss.update(s); 
		tx.commit();
		System.out.println(s);
		return s;
	}
	@DeleteMapping("deleteRecord")
	public Student deleteRecord() {
		
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Student s=ss.load(Student.class, 112);
		ss.delete(s);
		tx.commit();
		System.out.println(s);
		return s;

}
}








