package com.jbk.Spring.Hibernate.Integration;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class EmpolyeeController {
	@Autowired
	SessionFactory sf;
	
	@PostMapping("insertRecordemp")
	public Empolyee22 inserrecord() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		//Empolyee22 e =new Empolyee22 (1, "Vaishali");
		Empolyee22 e1 =new Empolyee22 (2, "Sakshi");
		Empolyee22 e2 =new Empolyee22 (3, "Monika");
		Empolyee22 e3 =new Empolyee22 (4, "Ankita");
		Empolyee22 e4 =new Empolyee22 (5, "Komal");
		Empolyee22 e5 =new Empolyee22 (6, "Riya");
		Empolyee22 e6 =new Empolyee22 (7, "Manisha");
		Empolyee22 e7 =new Empolyee22 (8, "Shalini");
		Empolyee22 e8 =new Empolyee22 (9, "Shyam");
		Empolyee22 e9 =new Empolyee22 (10, "Mahesh");
		Empolyee22 e10 =new Empolyee22 (12, "Vitthal");
		Empolyee22 e11 =new Empolyee22 (11, "Gauri");
		Empolyee22 e12 =new Empolyee22 (13, "Snehal");
		ss.save(e12);
		tx.commit();
		
		
		return e12;
		
	}
	@GetMapping("GetAllRecord")
	public List showallrecord() {
		Session ss=sf.openSession();
		String hql="from Empolyee22";
		Query query=ss.createQuery(hql);
		List r=query.list();
		
		return r;
		
	}
	

}
