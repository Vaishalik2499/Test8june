package com.jbk.Spring.Hibernate.Integration;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoPathveriableRequestBody {
	@RequestMapping("DempPathvariable/{id}")
	void DempPathvariable(@PathVariable int id) {
		System.out.println(id);
		
	}
	@RequestMapping("String/{name}")
	String DempPathvariableString(@PathVariable String name) {
		System.out.println(name);
		return name;
	}
	@GetMapping("Reuestbody")
	int DemoRequestBody(@RequestBody int id) {
		System.out.println(id);
		return id;
		
	}
	@GetMapping("DemoStringRequest")
	String DemoStringRequest(@RequestBody String name) {
		System.out.println(name);
		return name;
	}
	
	

}
