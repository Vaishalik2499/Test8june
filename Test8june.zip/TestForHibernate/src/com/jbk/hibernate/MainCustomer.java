package com.jbk.hibernate;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.internal.build.AllowSysOut;



public class MainCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(Customer.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		
		Transaction tx=ss.beginTransaction();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Insert Record");
		System.out.println("2.Update Record ");
		System.out.println("3.Delete Record ");
		System.out.println("4.Load Single Record ");
		System.out.println("5.Get Single Record ");
		int choice=sc.nextInt();
		switch(choice) {
		// insert record
		case 1:
			Customer cust=new Customer();
			//System.out.println("Enter id");
			cust.setId(788);
			
			//System.out.println("Enter name");
			cust.setName("Rushal");
			//System.out.println("Enter City");
			cust.setCity("Aurangabad");
			ss.save(cust);
			System.out.println("Record Inserted"+cust);
			break;
			
			//update record
		case 2:
			Customer cust1=new Customer();
			//System.out.println("Enter id");
			cust1.setId(78);
			//System.out.println("Enter name");
			cust1.setName("Neelam");
			ss.update(cust1);
			System.out.println("Record updated"+cust1);
			//delete record
		case 3:
			Customer cust2=ss.get(Customer.class, 2);
			ss.delete(cust2);
			System.out.println("Record deleted"+cust2);
			break;
			
			//load data
		case 4:
			System.out.println("Enter id");
			Customer cust3=ss.load(Customer.class, sc.nextInt());
			System.out.println(cust3.getId());
			System.out.println(cust3.getName());
			System.out.println(cust3.getCity());
			System.out.println("Record loaded" + cust3);
			break;
			//get data
		case 5:
			System.out.println("Enter id");
			Customer cust4=ss.get(Customer.class, sc.nextInt());
			System.out.println(cust4.getId());
			System.out.println(cust4.getName());
			System.out.println(cust4.getCity());
			System.out.println("Get Record" +cust4);
			break;
		default:
			break;
		}
		tx.commit();
		ss.close();
		sc.close();
			
			
			
			
			
		
		}
		

	}


