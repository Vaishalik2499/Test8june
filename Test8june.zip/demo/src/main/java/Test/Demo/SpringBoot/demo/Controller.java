package Test.Demo.SpringBoot.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import Test.Demo.SpringBoot.demo.Model.Login;
import Test.Demo.SpringBoot.demo.Model.Student2;


@RestController
public class Controller {
	
	@Autowired
	SessionFactory sf;
	@GetMapping("/")
	 public String login() {
		
		
		return "login.jsp";
		
		
	}
		
	@PostMapping("InsertRecord")
      public	Student2 inserRecord() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Student2 stud=new Student2(1, "AA");
		ss.save(stud); 
		tx.commit();
		System.out.println(stud);
		return stud;
	}
	@PutMapping("updateRecord")
    public	Student2 updateRecord() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Student2 stud=new Student2(1, "Kolhe");
		ss.update(stud); 
		tx.commit();
		
		System.out.println(stud);
		return stud;
	}
	@DeleteMapping("deleteRecord")
    public	Student2 deleteRecord() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Student2 stud=new Student2(1, "Kolhe");
		ss.delete(stud); 
		
		System.out.println(stud);
		return stud;
	}

}
