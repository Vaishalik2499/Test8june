package Test.Demo.SpringBoot.demo.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Login {
	@Id
	String Username;
	String Pass;
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Login(String username, String pass) {
		super();
		Username = username;
		Pass = pass;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPass() {
		return Pass;
	}
	public void setPass(String pass) {
		Pass = pass;
	}
	@Override
	public String toString() {
		return "Login [Username=" + Username + ", Pass=" + Pass + "]";
	}
	
	

}
