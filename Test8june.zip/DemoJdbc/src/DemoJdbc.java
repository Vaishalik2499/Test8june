import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DemoJdbc {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		Statement st=con.createStatement();
		//int result=st.executeUpdate("insert into student values (120,'Rishi')");
		int result=st.executeUpdate("delete from  student where studid=120");
	//int result=st.executeUpdate("update student set studnm='Riya' where studid=120 ");

		System.out.println("Record Deleted...." + result);
		String str="select * from student ";
		
		ResultSet rs=st.executeQuery(str);
		while(rs.next())
		{
			System.out.println(rs.getInt(1) +" "+ rs.getString(2));
		}
		

	}

}
