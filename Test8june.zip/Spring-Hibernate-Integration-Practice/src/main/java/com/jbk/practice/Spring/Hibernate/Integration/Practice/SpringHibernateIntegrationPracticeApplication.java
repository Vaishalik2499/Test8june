package com.jbk.practice.Spring.Hibernate.Integration.Practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHibernateIntegrationPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHibernateIntegrationPracticeApplication.class, args);
		System.out.println("Spring Running");
	}

}
