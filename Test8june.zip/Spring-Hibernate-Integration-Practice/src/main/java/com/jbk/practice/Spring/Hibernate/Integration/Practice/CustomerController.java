package com.jbk.practice.Spring.Hibernate.Integration.Practice;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("SingleRecord")
	public Customer showSinglerecord() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Customer c =ss.load(Customer.class, 11);
		System.out.println(c);
		return c;
	}
	@RequestMapping("multipleRecord")
	public List multipleRecord() {
		Session ss=sf.openSession();
		String str="from Customer";
		Query query=ss.createQuery(str);
		List list=query.list();
		System.out.println(list);
		return list;
		
				
	}
	
	
	@PostMapping("Insert")
	public Customer addCustomer(@RequestBody Customer c) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		//Customer c=new Customer(111,"Riya","Pune");
		ss.save(c);
		System.out.println(c);
		tx.commit();
		return c;
		
	}
	@PutMapping("UpdateRecord")
	public Customer updatecustomer(@RequestBody Customer c) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		//Customer c=new Customer(11,"Senhal","Aurangabad");
		ss.update(c);
		System.out.println(c);
		tx.commit();
		return c;
	}
	@DeleteMapping("deleteRecord/{id}")
	public Customer deleteRecord() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		//Customer c =new Customer();
		Customer c =ss.load(Customer.class, 11);
		ss.delete(c);
		tx.commit();
		System.out.println(c);
		return c;
	}

}







