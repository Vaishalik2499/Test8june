package com.jbk.practice.Spring.Hibernate.Integration.Practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernateIntegrationPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
