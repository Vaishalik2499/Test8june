package com.jbk.My.First.API.Project;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	@RequestMapping("Number")
	public int Number()
	{
		System.out.println("Number");
		return 5000;
	}
	
	@RequestMapping("MyName")
	public String MyName() {
		System.out.println("MyName");
		return "Vaishali";
	}
	
	@RequestMapping("City")
	String City() {
		return "Pune";
	}

}
