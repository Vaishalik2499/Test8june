package com.jbk.My.First.API.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstApiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
