package com.jbk.My.Third.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyThirdApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyThirdApiApplication.class, args);
		System.out.println("My Spring Running");
	}

}
