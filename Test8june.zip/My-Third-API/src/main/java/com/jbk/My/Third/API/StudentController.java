package com.jbk.My.Third.API;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class StudentController {
	

	ArrayList<Student>al=new ArrayList<>();
	
	public StudentController() {
		al.add(new Student(101,"Vaishali"));
		al.add(new Student(102,"Riya"));
		al.add(new Student (103,"Komal"));
		al.add(new Student(104,"Aaru"));
		
	}
	@RequestMapping("ShowAllStudentRecord")
	ArrayList<Student> getAllStudentRecord(){
		System.out.println("Multiple record show" +al);
		return al;
		
	}
	@GetMapping("ShowSingleRecord/{id}")
	
	Student getAllStudentRecord2( @PathVariable int id){
		Student ss=null;
		for (Student student : al) {
			if(student.id==id) {
			ss=student;
			
			}
		}
		System.out.println("Single record show" +al);
		return ss;
	}
	@PostMapping("insertstudent")
	public Student addStudent(@RequestBody Student student){
		al.add(student);
		System.out.println("Insert Record "+ student);
		
		
		return student;
	}
	@PutMapping("updateStudent")
	ArrayList<Student> updateStudent(@RequestBody Student student) {

		Student student2 = new Student();

		for (Student student3 : al) {
			if (student3.id == student.id) {
				student2 = student3;
			}
		}
		student2.setId(student.id);
		student2.setName(student.name);
		
		System.out.println(student2);
		return al;
		
	}
	@DeleteMapping("deleteStudent/{id}")
	public Student deleteStudent(@PathVariable int id) {
		Student student=new Student();
		
		for (Student student2 : al) {
			if (student2.id==id) {
				student=student2;
			}
		}
		al.remove(student);
		System.out.println(al);
		return student;
	
	}

}

