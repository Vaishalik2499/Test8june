
public class Butterflay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=4;
		//First half/Upper part  (i=1 to n)
		for(int i=1;i<=n;i++) {
			
			for(int j=1;j<=i;j++) {
				System.out.print("*");
				
			}
			// for Spaces 2*(n-i)
			int spaces=2*(n-i);
			for(int j=1;j<=spaces;j++) {
				System.out.print(" ");
			}
			//upper part ............2nd half
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		//Lower part 1st half..........(i=n to )
		for(int i=n;i>=0;i--) {
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			//spaces
			int spaces=2*(n-i);
			for(int j=1;j<=spaces;j++) {
				System.out.print(" ");
			}
			//lower 2nd part
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
