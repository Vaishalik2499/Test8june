
public class PalindromicPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		//row print
		for(int i=1;i<=n;i++) {
			
			//Spaces(n-i)
			for(int j=1;j<=n-i;j++) {
				System.out.print(" ");
			}
			// for back word direction i to 1
			for(int j=i;j>=1;j--) {
				System.out.print(j);
			}
			//for forwad direction but start with 2
			for(int j=2;j<=i;j++) {
				System.out.print(j);
			}
			System.out.println();
		}

	}

}
