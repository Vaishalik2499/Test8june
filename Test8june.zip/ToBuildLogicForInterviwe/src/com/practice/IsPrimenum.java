package com.practice;

import java.util.Scanner;

public class IsPrimenum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
	   // Scanner scanner = new Scanner(System.in);
       // System.out.print("Enter a number: ");
       // int number = scanner.nextInt();
		int number=13;
        
        if (isPrime(number)) {
            System.out.println(number + " is a prime number.");
        } else {
            System.out.println(number + " is not a prime number.");
        }
        
        if (number > 9) {
            System.out.println("Checking each digit for primality:");
            int tempNumber = number;
            while (tempNumber > 0) {
                int digit = tempNumber % 10;
                if (isPrime(digit)) {
                    System.out.println(digit + " is a prime digit.");
                } else {
                    System.out.println(digit + " is not a prime digit.");
                }
                tempNumber = tempNumber /10;
            }
        }
    }
    
    // Function to check whether a number is prime
    private static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        
        return true;
	}

}
