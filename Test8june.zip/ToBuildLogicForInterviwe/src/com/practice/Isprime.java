package com.practice;

public class Isprime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=15;
		if(Isprime(number)) {
			System.out.println(number + " Is prime number");
			
		}
		else {
			System.out.println(number + " Is not prime number");
	}
	if(number > 9) {
		 System.out.println("Checking each digit for primality:");
		int tempnum=number;
		while(tempnum >0) {
			int digit=tempnum%10;
			if(Isprime(digit)) {
				System.out.println(digit + " Is prime digit");
				
			}
			else {
				System.out.println(digit + " Is not prime digit");
				
			}
			tempnum= tempnum /10;
			
		}
		
		
	}
	}
	private static boolean Isprime(int number) {
		if(number<=1) {
		return false;
	}
	
	for(int i=2;i<=Math.sqrt(number);i++) {
		if(number%i==0) {
			return false;
		}
		
	}
	return true;
}
}
