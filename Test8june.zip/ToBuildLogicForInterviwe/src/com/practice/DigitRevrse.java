package com.practice;

public class DigitRevrse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=123;
		int sum=0;
		while(n>0) {
			int rev=n%10;
			sum=(sum*10)+rev;
			n=n/10;
		}
		System.out.println(sum);

	}

}
