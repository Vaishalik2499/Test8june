package com.fileHandling;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Filewrite {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
			FileWriter fw=new FileWriter("myfile.txt");
			System.out.println("Enter Contain to want to stored");
			String s=sc.nextLine();
			fw.write(s);
			System.out.println("Succesfully");
			
		
		

	}

}
