package com.fileHandling;

import java.util.Scanner;

public class Isprime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	   // Scanner scanner = new Scanner(System.in);
        //System.out.print("Enter a number: ");
        //int num = scanner.nextInt();
		int num=13;

        // Check if the number is greater than 9
        if (num > 9) {
            // Separate the number into its individual digits
            while (num > 0) {
                int digit = num % 10;
                num /= 10;
                if (!isPrime(digit)) {
                    System.out.println("The number is not prime");
                    return;
                }
            }
            System.out.println("The number is prime");
        } else {
            if (isPrime(num)) {
                System.out.println("The number is prime");
            } else {
                System.out.println("The number is not prime");
            }
        }
    }

    // Check if a given number is prime
    private static boolean isPrime(int num) {
        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

	}


