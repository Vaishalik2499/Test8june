package com.fileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class ExHashMAp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        try {
            // Open the file for reading
            File file = new File("myfile.txt");
            Scanner scanner = new Scanner(file);
            
            // Create a new HashMap to store the data
            HashMap<String, Integer> data = new HashMap<>();
            
            // Read each line of the file and store the data in the HashMap
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                String firstName = parts[0];
                String lastName = parts[1];
                int age = Integer.parseInt(parts[2]);
                data.put(firstName + " " + lastName, age);
            }
            
            // Close the scanner
            scanner.close();
            
            // Print the contents of the HashMap
            System.out.println("Data:");
            for (String key : data.keySet()) {
                int age = data.get(key);
                System.out.println(key + " - " + age + " years old");
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("The file was not found.");

	}

}
}
