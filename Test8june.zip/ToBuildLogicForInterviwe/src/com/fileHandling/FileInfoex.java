package com.fileHandling;

import java.io.File;
import java.sql.Date;

public class FileInfoex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File apath=new File("myfile.txt");
		//check if Exists
		System.out.println("Path exists :" +apath.exists());
		
		if(apath.exists()) {
			System.out.println("Directory "+apath.isDirectory());
			
			System.out.println("Hideen "+apath.isHidden());
			
			System.out.println("Simple name = "+ apath.getName());
			System.out.println("Absolute Path = " + apath.getAbsolutePath());
			//check file size in bytes
			System.out.println("Length :" +apath.length());
			//last modify
			
			long lastModifyInMillis = apath.lastModified();
			
			Date lastModifyDate = new Date(lastModifyInMillis);
			
			System.out.println( "Last modify date:" +lastModifyDate);
			
		}
		

	}

}
