package com.fileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class ExFileHandlinCount {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		File f=new File("myfile.txt");
		Scanner sc=new Scanner(f);
		String s=sc.next();
		
		char ch='a';
		int count=0;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)==ch) {
				count++;
			}
		}
		System.out.println(ch +" "+ count);
		
		

	}

}
