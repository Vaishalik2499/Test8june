package com.Collection;

import java.util.ArrayList;
import java.util.Collections;


public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(0);
		al.add(2);
		al.add(3);
		System.out.println(al);
		
		int size=al.size();
		System.out.println("Size Of ArrayList " +size);
		
		// adding element in 1st index
		al.add(1, 1);
		System.out.println(al);
		
		al.add(0, 5);
		System.out.println(al);
		
		//sorting ArrayList
		Collections.sort(al);
		System.out.println(al);
		
		//Remove Element on the basis of index
		al.remove(4);
		System.out.println(al);
		
		//Iterate ArrayList By Using For loop
		for(int i=0;i<al.size();i++) {
			System.out.println(al.get(i));
		}
	
		
	

	}

}
