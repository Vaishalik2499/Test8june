package com.Collection;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamApiUse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>al=Arrays.asList(12,22,13,15,16,9,2,3,27);
		al.stream().filter(n->n%2==0).forEach(System.out::println);
		
		//al.stream().filter(n->n%2!=0).forEach(System.out::println);

	}

}
