package com.Collection;

public class Isprime {

	public static void main(String[] args) {
	int n=13;
	if(Isprime(n)) {
		System.out.println(n +"Is prime number");
		
	}
	else
	{
		System.out.println(n +"Is not prime number");
	}
	if(n>9) {
		int temp=n;
		while(temp>0) {
			int digit=temp%10;
			if(Isprime(digit)) {
				System.out.println(digit +"Is prime digit");
			}
			else {
				System.out.println(digit +"Is not prime digit");
			}
			temp=temp/10;
				
		}
	}
	}

	private static boolean Isprime(int n) {
		if(n<=1) {
			return false;
		}
		for(int i=2;i<=Math.sqrt(n);i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}

}
