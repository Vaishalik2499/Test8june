
public class DiamondPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=4;
		//1st half.....
		for(int i=1;i<=n;i++) {
			//spaces(n-i)
			for(int j=1;j<=n-i;j++) {
				System.out.print(" ");
			}
			//stars = 2*i-1
			for(int j=1;j<=2*i-1;j++) {      
				// i=1..star=1
				// i=2.........star=2*2-1=3
				//i=3........star =2*3-1=5
				// i=4........star = 2*4-1=7
				System.out.print("*");
			}
			System.out.println();
		}
		
		//2nd half Reverse
		for(int i=n;i>=1;i--) {
			//spaces
			for(int j=1;j<=n-i;j++) {
				System.out.print(" ");
				
			}
			for(int j=1;j<=2*i-1;j++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
