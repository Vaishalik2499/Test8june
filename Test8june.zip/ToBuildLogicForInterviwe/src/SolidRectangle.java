
public class SolidRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row=4,cloumn=10;
		for(int i=1;i<=row;i++) {
			for(int j=1;j<=cloumn;j++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
