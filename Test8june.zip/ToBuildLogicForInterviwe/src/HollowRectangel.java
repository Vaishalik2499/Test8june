
public class HollowRectangel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row=4,cloumn=5;
		for(int i=1;i<=row;i++) {
			for(int j=1;j<=cloumn;j++) {
				if(i==1||i==row||j==1||j==cloumn) {
					System.out.print("*");
				}
				else
					System.out.print(" ");
			}
			System.out.println();
		}

	}

}
