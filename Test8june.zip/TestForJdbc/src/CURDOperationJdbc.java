import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class CURDOperationJdbc {
	public static void main(String[] args) throws Exception {
		
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/practice", "root", "root");
	Statement stmt=con.createStatement();
	int choice;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Your Choice");
	System.out.println("1.Insert Record");
	System.out.println("2.Update Record");
	System.out.println("3.Delete Record");
	System.out.println("4.Display Record");
	
	System.out.println("5.Exit");
	 choice=sc.nextInt();
	 System.out.println();
	switch(choice)
	{
	case 1:
		stmt.executeUpdate("insert into student values (205,'Riya',78.5)");
		System.out.println("Record inseted");
		break;
	case 2:
		stmt.executeUpdate("update student set studnm='Rinna' where studid=4");
		System.out.println("Record updated");
		break;
	case 3:
		stmt.executeUpdate("delete from student where studid=204");
		System.out.println("Record deleted");
		break;
	case 4:
		ResultSet rs= stmt.executeQuery("select*from student");
		while(rs.next())
		{
			System.out.println(rs.getInt(1) +"  "+ rs.getString(2) +" " +rs.getFloat(3));
		}
		break;
	case 5:
		System.exit(0);
		break;
		default:
			System.out.println("Invalid choice . Plz try Again");
		
		
	}
	sc.close();
	
	
	
}

}
