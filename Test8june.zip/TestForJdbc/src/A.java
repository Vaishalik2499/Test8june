import java.util.ArrayList;
import java.util.HashMap;

public class A {

	public static void main(String[] args) {
		
		HashMap<Integer, Student>hm=new HashMap<Integer, Student>();
		//ArrayList<Student> al=new ArrayList<Student>();
		Student s=new Student(1,"Riya",89);
		//al.add(s);
		hm.put(1, s);
		System.out.println(hm);
		
		for (String string : args) {
			System.out.println(string);
			
		}
		
		
	}
}