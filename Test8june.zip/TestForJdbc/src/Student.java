
public class Student {
	int studid;
	String studnm;
	float per;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int studid, String studnm, float per) {
		super();
		this.studid = studid;
		this.studnm = studnm;
		this.per = per;
	}
	public int getStudid() {
		return studid;
	}
	public void setStudid(int studid) {
		this.studid = studid;
	}
	public String getStudnm() {
		return studnm;
	}
	public void setStudnm(String studnm) {
		this.studnm = studnm;
	}
	public float getPer() {
		return per;
	}
	public void setPer(float per) {
		this.per = per;
	}
	@Override
	public String toString() {
		return "Student [studid=" + studid + ", studnm=" + studnm + ", per=" + per + "]";
	}
	

}
