
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class CurdoperationforCustomer {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/practice", "root", "root");
		Statement stmt=con.createStatement();
		int choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Choice");
		System.out.println("1.Insert Record");
		System.out.println("2.Update Record");
		System.out.println("3.Delete Record");
		System.out.println("4.Display Record");
		
		System.out.println("5.Exit");
		 choice=sc.nextInt();
		 System.out.println();
		switch(choice)
		{
		case 1:
			stmt.executeUpdate("insert into customer001 values (3,'Riya','Akola')");
			System.out.println("Record inseted");
			break;
		case 2:
			stmt.executeUpdate("update customer001 set Name='Rinna' where id=1");
			System.out.println("Record updated");
			break;
		case 3:
			stmt.executeUpdate("delete from customer001 where id=2");
			System.out.println("Record deleted");
			break;
		case 4:
			ResultSet rs= stmt.executeQuery("select*from customer001");
			while(rs.next())
			{
				System.out.println(rs.getInt(1) +"  "+ rs.getString(2) +" " +rs.getString(3));
			}
			break;
		case 5:
			System.exit(0);
			break;
			default:
				System.out.println("Invalid choice . Plz try Again");
			
			
		}
		sc.close();
		

	}

}
