package com.JBK.logical;

public class OddPostion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,30,40,50,60,70,80};
		for (int i = 1; i < a.length; i=i+2) {
			System.out.print(" "+a[i]);
			
		}

	}

}
