package com.JBK.logical;

public class OddPositionInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {0,1,2,3,4,5};
		for (int i = 1; i < a.length; i=i+2) {
		
			System.out.print(" "+a[i]);
			
		}

	}

}
