package com.JBK.logical;

public class FindVowel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello My Name Is Vaishali";
		
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)=='a'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u'||s.charAt(i)=='e') {
				System.out.println(s.charAt(i) +" "+ i);
				
			}
			
		}

	}

}
