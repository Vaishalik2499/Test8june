package com.JBK.logical;

public class Even_number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n[]= {2,5,8,3,4,6};
		for (int i = 0; i < n.length; i++) {
			if(n[i]%2==0) {
				System.out.println("Even number="+n[i]);
			}
			
		}
		for (int i = 0; i < n.length; i++) {
			if(n[i]%2!=0) {
				System.out.println("Odd number="+n[i]);
			}

	}

	}}
