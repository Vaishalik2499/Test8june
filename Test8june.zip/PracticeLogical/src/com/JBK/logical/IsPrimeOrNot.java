package com.JBK.logical;

public class IsPrimeOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=11;
		int count=0;
		
		for (int i = 2; i <n; i++) {
			if(n%i==0) {
				count++;
				break;
			}
			
			
		}
		if(count==0) {
			System.out.println("IsPrime");
		}
		else
			System.out.println("Is NotPrime");
		

	}

}
