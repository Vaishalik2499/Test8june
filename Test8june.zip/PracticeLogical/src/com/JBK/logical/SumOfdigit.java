package com.JBK.logical;

public class SumOfdigit {
	public static void main(String[] args) {
		int n=123;
		int sum=0;
		while(n>0) {
			int v=n%10;
			sum=sum+(v);
			n=n/10;
			
		}
		System.out.print(sum);
	}

}
