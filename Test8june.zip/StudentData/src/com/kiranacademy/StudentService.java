package com.kiranacademy;

import java.util.ArrayList;

public class StudentService {
	static ArrayList<Student>fetchStudents() throws Exception {
		ArrayList<Student> alStu=StudentDao.fetchStudents();
		
		ArrayList<Student> alStufilter=new ArrayList<Student> ();
		
		for (Student student : alStu) {
			if(!student.name.startsWith("V") ) {
				//System.out.println(student);
				//alStu.remove(student);
				alStufilter.add(student);
				
			}
			
		}
		
		return alStufilter;
	}


}
