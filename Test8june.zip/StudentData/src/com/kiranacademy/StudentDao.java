package com.kiranacademy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentDao {
	static ArrayList<Student>fetchStudents() throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
	
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		
		String str="select * from student";
		Statement stmt=con.createStatement();
		
		ResultSet rs=stmt.executeQuery(str);
		ArrayList<Student> alStu=new ArrayList<Student>();
		while(rs.next())
		{
			int id=rs.getInt(1);
			String name=rs.getString(2);
			float per=rs.getFloat(3);
			Student student=new Student(id, name, per);
			//System.out.println(id);
			//System.out.println(name);

			//System.out.println(per);

			
			alStu.add(student);
			
			
			//System.out.println(rs.getInt(1) +" "+ rs.getString(2)+ " "+ rs.getFloat(3));
		}
		
		return alStu;
	}

}
