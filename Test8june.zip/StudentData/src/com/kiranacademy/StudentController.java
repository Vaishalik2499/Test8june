package com.kiranacademy;

import java.util.ArrayList;

public class StudentController {
	static ArrayList<Student> fetchStudents() throws Exception {
		ArrayList<Student> alStu=StudentService.fetchStudents();
		return alStu;
		

}
}