package com.kiranacademy;
// youtude Advance java 4 class example,
import java.util.ArrayList;

public class StudentClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
			ArrayList<Student> al= StudentController.fetchStudents();
			for (Student s : al) {
				System.out.println(s.id);
				System.out.println(s.name);
				System.out.println(s.per);
				
			}
			
			

	}

}
