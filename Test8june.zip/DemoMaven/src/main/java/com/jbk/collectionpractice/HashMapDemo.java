package com.jbk.collectionpractice;

import java.util.HashMap;
import java.util.Iterator;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String>hm=new HashMap();
		hm.put(101, "Java");
		hm.put(102, "php");// duplicate values are alloed
		hm.put(103, "php");
		hm.put(102, ".net");  // duplicat key not allowed 
		
		System.out.println(hm);
	
	
		
		System.out.println(hm.get(101));

	}

}
