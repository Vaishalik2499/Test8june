package com.jbk.collectionpractice;
// program for to delete all elements from ArrayList
import java.util.ArrayList;

public class ArrayListDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<>();
		al.add("Zero");
		al.add("One");
		al.add("Two");
		al.add("Thrid");
		al.add("Random");
		System.out.println("Actual ArrayList:"+al);
		// this function delete all items from arraylist
		al.clear();
		System.out.println("\n After Clear Arraylist  "+al);
		

	}

}
