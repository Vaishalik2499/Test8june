package com.jbk.collectionpractice;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String>l=new LinkedList();
		l.add("Vaishali");
		l.add("Priya");
		l.add("Riya");
		
		System.out.println(l);
				

	}

}
