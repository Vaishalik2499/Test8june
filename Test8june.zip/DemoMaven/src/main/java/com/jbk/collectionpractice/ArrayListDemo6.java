package com.jbk.collectionpractice;
// Program for to copy ArrayList into array

import java.util.ArrayList;

public class ArrayListDemo6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<>();
		al.add("Pune");
		al.add("Mumbai");
		al.add("Nagpur");
		al.add("Nashik");
		System.out.println("Actual Arraylist :"+al);
		String []arr=new String[al.size()];
		al.toArray(arr);
		System.out.println("\n Create Array Content:");
		for(String s:arr)
		{
			System.out.println(arr);
		}

	}

}
