package com.jbk.collectionpractice;

import java.util.HashSet;

public class HashSetDemo6 {
// program for compare two sets and retain elements which are same on 
	//both hashsets
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSet<String>h=new HashSet<>();
		h.add("Java");
		h.add("By");
		h.add("Kiran");
		h.add("KarveNagar");
		h.add("Pune");
		System.out.println("First:"+h);
		
		
		HashSet<String>hs=new HashSet<>();
		hs.add("Java");
		hs.add("J2EE");
		hs.add("Selenium");
		System.out.println("Second Hashset:"+ hs);
		h.retainAll(hs);
		
		// this function retain common element from both hashset
		System.out.println("" + "Common Hashset content from both:");
		System.out.println(h);
		

	}

}
