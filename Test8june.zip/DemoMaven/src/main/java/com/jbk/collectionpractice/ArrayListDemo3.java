package com.jbk.collectionpractice;
//program for to add all elements of a list to ArrayList
import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated String stub
		ArrayList<String>al=new ArrayList<>();
		al.add("First");
		al.add("Second");
		al.add("Third");
		al.add("Random");
		System.out.println("Before Actual ArrayList:"+al);
		List<String>list=new ArrayList();
		list.add("one");
		list.add("Two");
		al.addAll( list);
		System.out.println("\n After copy ArrayList:" +al);

	}

}
