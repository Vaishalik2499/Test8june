package com.jbk.collectionpractice;

// Program for to iterate HashSet element through iterator
import java.util.HashSet;
import java.util.Iterator;

public class HashDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String>h=new HashSet<>();
		h.add("Java");
		h.add("By");
		h.add("Kiran");
		Iterator<String>itr=h.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}

	}

}
