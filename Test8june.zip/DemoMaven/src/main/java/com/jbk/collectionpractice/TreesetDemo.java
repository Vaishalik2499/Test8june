package com.jbk.collectionpractice;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String>t=new TreeSet();  // order not maintain
		t.add("python");
		t.add("java");
		t.add("Php");
		t.add("python");//dupliccate not allowed
		t.add("java");
		Iterator<String>itr=t.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println(t);
		
		TreeSet<Integer>s=new TreeSet();
		s.add(101);
		s.add(102);
		s.add(103);
		s.add(101); //duplicate not allowed
		System.out.println(s);

	}

}
