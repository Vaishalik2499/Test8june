package com.jbk.collectionpractice;
// Program for basic hashset operations
import java.util.HashSet;

public class HashSetDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String>h=new HashSet<>();
		h.add("Java");
		h.add("By");
		h.add("Kiran");
		System.out.println(h);
		System.out.println("Hashset is Empty or Not:"+ h.isEmpty());
		h.remove("Kiran");
		System.out.println(h);
		System.out.println("Siza="+ h.size());
		System.out.println("Hashset contains Java or not: "+h.contains("Java"));

	}

}
