package com.jbk.collectionpractice;
// program to read all elements in ArrayList by using an iterator
import java.util.ArrayList;
import java.util.Iterator;


public class ArrayListPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<>();
		al.add("Java");
		al.add("Php");
		al.add("java");
		al.add("Python");
		Iterator<String>itr=al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	//	System.out.println(al);
		
		
		ArrayList<Integer>i=new ArrayList();
		i.add(101);
		i.add(202);
		i.add(303);
		System.out.println(i);
		
	
		
		
}
}