package com.jbk.collectionpractice;
//program for display arraylist and its operation
import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<>();
		al.add("PERL");
		al.add("PHP");
		System.out.println(al);
		System.out.println("Element at Index 1:"+al.get(1));
		System.out.println("Does list contain Java?"+al.contains("Java"));
		System.out.println(al);
		System.out.println("Is Array List Empty?" +al.isEmpty());
		System.out.println("Index Of PERL is:" +al.indexOf("PERLs"));
		System.out.println("Size of Array lits Is:" +al.size());

	}

}
