package com.jbk.collectionpractice;

import java.util.HashSet;

public class Hashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<Integer>h=new HashSet();
		h.add(102);
		h.add(360);
		h.add(505);
		h.add(101);
		h.add(102);
		h.add(505);
		h.add(401);
		
		System.out.println(h);
		
		HashSet<String>hs=new HashSet();
		hs.add("Java");
		hs.add("Php");
		hs.add("Python");
		System.out.println(hs);

	}

}
