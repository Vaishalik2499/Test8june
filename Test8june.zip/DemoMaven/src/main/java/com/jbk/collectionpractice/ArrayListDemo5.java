package com.jbk.collectionpractice;
// program to find does ArrayList contains all list elements or not

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<>();
		al.add("Zero");
		al.add("First");
		al.add("Two");
		al.add("Third");
		al.add("Random");
		List<String>list=new ArrayList<>();
		list.add("Two");
		list.add("Random");
		System.out.println("Does ArrayList Contains all Element: "+al.containsAll(list));
		list.add("One");
		System.out.println("\n Does ArrayList Contains all Element:" +al.contains(list));
		

	}

}
