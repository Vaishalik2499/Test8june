package com.prepration;

public class RemoveSpcaeString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Vaishali Kolhe";
		s=s.replaceAll(" ", "");
		System.out.println(s);
		System.out.println(s.length());
		System.out.println(s.isEmpty());

	}

}
