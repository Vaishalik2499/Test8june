package com.prepration;

import java.util.Scanner;

public class Without3rdVar {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st value");
		int a=sc.nextInt();
		//int a=50;
		System.out.println("Enter 2nd value");
		int b=sc.nextInt();
		//int b=60;
		System.out.println("BeforeSwapping= " +a+" "+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("AfterSwapping= " +a+" "+b);

	}

}
