package com.prepration;

public class ThreadEx extends Thread {
	public void run() {
		System.out.println("111");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadEx t=new ThreadEx();
		t.start();

	}

}
