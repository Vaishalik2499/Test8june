package com.prepration;

public class OddpositionInarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,11,12,13,14,15,16};
		for (int i = 1; i < a.length; i=i+2) {
			System.out.println(a[i]);
			
		}
	}

}
