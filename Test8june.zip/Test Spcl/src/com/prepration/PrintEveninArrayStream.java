package com.prepration;

import java.util.Arrays;
import java.util.List;

public class PrintEveninArrayStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>al=Arrays.asList(12,21,55,48,9,6,7,4,5,20,10,30,8);
		al.stream().filter(n->n%2==0).forEach(System.out::println);
		al.stream().filter(n->n%2!=0).forEach(System.out::println);
	}

}
