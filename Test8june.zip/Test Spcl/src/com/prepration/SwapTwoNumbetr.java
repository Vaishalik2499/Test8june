package com.prepration;

public class SwapTwoNumbetr {

	public static void main(String[] args) {
	int a=10;
	int b=30;
	int temp;
	temp=a;
	a=b;
	b=temp;
	System.out.println(a +" "+b);
	}

}
