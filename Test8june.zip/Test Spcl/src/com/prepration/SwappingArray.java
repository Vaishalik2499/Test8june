package com.prepration;

import java.util.Arrays;

public class SwappingArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a1[]= {1,2,3,4,5};
		int a2[]= {6,7,8,9,10};
		
		int temp[]=a1;
		a1=a2;
		a2=temp;
		System.out.println(Arrays.toString(a1));
		System.out.println(Arrays.toString(a2));
	
		
		
		

	}

}
