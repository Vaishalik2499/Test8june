package com.prepration;

import java.util.stream.Stream;

public class StreamApiName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stream<String>str=Stream.of("Vaishali","Kisan","Kolhe");
		str.forEach(System.out::println);

	}

}
