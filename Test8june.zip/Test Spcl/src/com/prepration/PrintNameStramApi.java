package com.prepration;

import java.util.ArrayList;
import java.util.stream.Stream;

public class PrintNameStramApi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stream<String>str=Stream.of("Vaishali","A","b","c");
		str.forEach(n->System.out.println(n));
	}

}
