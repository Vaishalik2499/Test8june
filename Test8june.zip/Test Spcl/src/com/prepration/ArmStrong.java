package com.prepration;

import java.util.Scanner;

public class ArmStrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=375;                                //  ArmStrong Numbers=153,370,371...
		int temp=n;
		int sum=0;
		while(n>0) {
			int v=n%10;
			sum=sum+(v*v*v);
			n=n/10;
			
		}
		if(sum==temp) {
			System.out.println("Armstrong");
		}
		else
			System.out.println("not Armstrong");

	}

}
