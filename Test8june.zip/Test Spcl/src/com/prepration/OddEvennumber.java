package com.prepration;

import java.util.Scanner;

public class OddEvennumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=27;
		//Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		//int n=sc.nextInt();
		if(n%2==0) {
			System.out.println("even");
		}
		else {
			System.out.println("odd");
		}
	}

}
