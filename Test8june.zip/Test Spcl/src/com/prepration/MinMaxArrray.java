package com.prepration;

import java.util.Arrays;

public class MinMaxArrray {
	static void Minmax(int arr[]) {
		 long min=0;
		 long max=0;
		 
		 int n=arr.length;
		 Arrays.sort(arr);
		 for(int i=0,j=n-1;i<n-1;i++,j--) {
			 min += arr[i];
			 max +=arr[j];
			 
			 
		 }
		 System.out.println(min +" "+max);
		 System.out.println(arr[arr.length-1]);
		 System.out.println(arr[0]);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {10,12,13,14};
		Minmax(arr);

	}

}
