

package com.practice;

public class Patternright {

	public static void main(String[] args) {
		
		
		
		
		

	}

}
