package com.test;
 //Print name  in collection by using stream api

import java.util.stream.Stream;

public class PrintName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stream<String>str=Stream.of("Vaishali", "Sneha", "Riha","Richa","Asha");
		str.forEach(s->System.out.println(s));
	}

}
