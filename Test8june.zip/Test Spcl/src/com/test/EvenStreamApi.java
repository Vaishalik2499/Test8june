package com.test;
// Pringt Even number in collection by using Stream Api
import java.util.Arrays;
import java.util.List;

public class EvenStreamApi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>number=Arrays.asList(27,4,8,23,9,8,14,26,7,11,19);
		number.stream().filter(n -> n%2==0).forEach(System.out::println);

	

}
}