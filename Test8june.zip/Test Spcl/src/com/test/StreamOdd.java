package com.test;

import java.util.Arrays;
import java.util.List;

public class StreamOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>al=Arrays.asList(27,5,18,9,4,12,3,8,47,6);
		al.stream().filter(n->n%2!=0).forEach(System.out::println);
		
		System.out.println("Even");
		al.stream().filter(n->n%2==0).forEach(System.out::println);

		List<Integer>l=Arrays.asList(2,3,8,9,6);
		l.stream().filter(n->n%2==0).forEach(System.out::println);
	}

}
