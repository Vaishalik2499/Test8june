package com.test;
// Sum of Array min max number and print min & max number
import java.util.Arrays;

public class SumOfArrayMin_MaxNumber {
	
	static void minMax(int[]arr) {
		 long min_value=0;
		 long max_value=0;
		 
		 int n=arr.length;
		 
		 Arrays.sort(arr);
		 for(int i=0, j=n-1; i<n-1; i++, j--) {
			 min_value +=arr[i];
			 
			 max_value +=arr[j];
		 }
		 System.out.println(min_value +" " +max_value);
		 System.out.println("max number="+arr[arr.length-1]);
		 System.out.println("min number="+arr[0]);
	}
	
	
	

	public static void main(String[] args) {
		
		int arr[]= {10,9,8,7,6,5};
	//	int arr1[]= {100,200,300,400,500};
		minMax(arr);
		///minMax(arr1);
		
		
			
			
			
		}
		

	}


