package com.test;

import java.util.Arrays;

public class ArraySwapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int ch1[]= {1,2,-3,4,5};
		int ch2[]= {6,7,8,9,10};
		int temp[];
		
		
	
		temp=ch1;
		ch1=ch2;
		ch2=temp;
		System.out.println(Arrays.toString(ch1));
		System.out.println(Arrays.toString(ch2));
		
		
		
	
			
			
			
		}
		
	
		

	}


