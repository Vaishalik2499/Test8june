package com.test;

import java.util.Arrays;

public class ArraySwapExample {
	   public static void main(String[] args) {
	      // Define two arrays
	      int[] array1 = {1, 2, 3, 4, 5};
	      int[] array2 = {6, 7, 8, 9, 10};

	    
	   

	    // Create a temporary array and copy array1 into it
	      int[] temp = Arrays.copyOf(array1, array1.length);

	      // Copy array2 into array1
	      System.arraycopy(array2, 0, array1, 0, array2.length);

	      // Copy the contents of the temporary array into array2
	      System.arraycopy(temp, 0, array2, 0, temp.length);

	      // Print the swapped arrays
	      System.out.println("Swapped arrays:");
	      System.out.println("Array 1: " + Arrays.toString(array1));
	      System.out.println("Array 2: " + Arrays.toString(array2));
	   }
	}

