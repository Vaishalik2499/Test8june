package com.test;

import java.util.Arrays;

public class MinMaxSumArray {
	static void minmax(int arr[]) {
		long min=0;
		long max=0;
		
		int n=arr.length;
		
		Arrays.sort(arr);
		for (int i = 0,j=n-1; i < n-1; i++,j--) {
			min +=arr[i];
			max +=arr[j];
			
			
		}
		System.out.println("Sum of min="+min +"   Sum of Max Number "+ max);
	    System.out.println("min number="+arr[0]);
	    System.out.println("max number="+arr[arr.length-1]);
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {10,2,13,84,15,6};
		minmax(arr);

	}

}
