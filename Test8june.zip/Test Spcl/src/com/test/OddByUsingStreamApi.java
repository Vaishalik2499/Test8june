package com.test;

import java.util.Arrays;
import java.util.List;

public class OddByUsingStreamApi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>number=Arrays.asList(27,4,89,23,5,6,7,2,1,9);
		number.stream().filter(n -> n%2 !=0).forEach(System.out::println);
		
		System.out.println("Even Number=");
		   number.stream().filter(n -> n%2==0).forEach(System.out::println);

	}

}
