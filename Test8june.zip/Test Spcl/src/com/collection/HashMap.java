package com.collection;

import java.util.Iterator;

public class HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.HashMap<Integer, String>hm=new java.util.HashMap<Integer, String>();
		hm.put(123, "Vaishali");
		hm.put(23, "Kisan");
		hm.put(236, "Kolhe");
		
		Iterator<Integer>itr=hm.keySet().iterator();
		while(itr.hasNext()) {
			int key=(int)itr.next();
			System.out.println(key +" "+hm.get(key));
		}

	}

}
