package com.collection;

import java.util.ArrayList;
import java.util.Iterator;


public class IteratoArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(101);
		al.add(202);
		al.add(564);
		
		Iterator<Integer>itr=al.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		

	}

}
