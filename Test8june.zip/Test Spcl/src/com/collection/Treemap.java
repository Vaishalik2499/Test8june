package com.collection;

import java.util.Iterator;

import java.util.TreeMap;

public class Treemap {

	public static void main(String[] args) {
		TreeMap<Integer, String>tm= new TreeMap<Integer, String>();
		tm.put(10, "Vaaishali");
		tm.put(12, "KIsa");
		tm.put(13, "Kolhe");
		
		Iterator< Integer>itr=tm.keySet().iterator();
		while(itr.hasNext()) {
			int key=(int)itr.next();
			System.out.println(key +" "+tm.get(key));
		}
		
	
		
	
	}

}
