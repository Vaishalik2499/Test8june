package com.collection;

import java.util.ArrayList;


public class ForeEachArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<String>();
		al.add("vvv");
		al.add("pp");
		al.add("mm");
		al.add("kk");
		
		for (int i = 0; i <al.size(); i++) {
			System.out.println(al.get(i));
			
		}
			
		}
		}
	


