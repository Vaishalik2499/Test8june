package com.logical;

public class DynamicPattern {
	static void print(int k,int l) {
		for(int i=1;i<=k;i++) {
			for(int j=1;j<=l;j++) {
				if(i==1||i==k||j==1||j==l) {
					System.out.print("*");
				}
				else
					System.out.print(" ");
				
			}
			System.out.println();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row=5,cln=5;
		print(row,cln);
		

	}

}
