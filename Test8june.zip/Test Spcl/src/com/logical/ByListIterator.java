package com.logical;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ByListIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>al=new ArrayList<Integer>();
		al.add(101);
		al.add(102);
		al.add(103);
		ListIterator<Integer>itr=al.listIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		

	}

}
