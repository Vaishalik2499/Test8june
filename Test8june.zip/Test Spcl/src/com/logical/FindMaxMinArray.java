package com.logical;

import java.util.Arrays;

public class FindMaxMinArray {
	static void Maxmin(int a[]) {
		long min=0;
		long max=0;
		
		int n=a.length;
		Arrays.sort(a);
		for(int i=0,j=n-1;i<n-1;i++,j--) {
			max +=a[i];
			min +=a[j];
			
			
		}
		System.out.println("Mix" +max);
		System.out.println(a[a.length-1]);
		System.out.println(a[0]);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,30,4,8,9};
		Maxmin(a);
		

	}

}
