package com.logical;

public class Oddeven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=12;
		if(n%2==0) {
			System.out.println("Even");
		}
		else
			System.out.println("Odd");

	}

}
