package com.logical;

import java.util.ArrayList;

public class ArrayByforloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(2);
		al.add(1);
		al.add(6);
		al.add(3);
		for (int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i));
			
		}

	}

}
