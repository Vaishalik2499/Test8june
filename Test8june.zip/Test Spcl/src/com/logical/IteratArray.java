package com.logical;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String>al=new ArrayList<String>();
		al.add("Vaishali");
		al.add("Kisan");
		al.add("Kolhe");
		
		Iterator<String>itr=al.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		

	}

}
