package com.logical;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Integer>tr=new TreeSet<Integer>();
		tr.add(101);
		tr.add(105);
		tr.add(102);
		tr.add(103);
		tr.add(101);
		
		Iterator<Integer>itr=tr.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
