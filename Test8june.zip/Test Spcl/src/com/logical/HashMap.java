package com.logical;

import java.util.Iterator;

public class HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.HashMap<Integer, String>hm=new java.util.HashMap<Integer, String>();
		hm.put(1, "Yes");
		hm.put(2, "No");
		hm.put(4, "ok");
		hm.put(3, "Hello");
		hm.put(1, "BigNo");
		
		Iterator<Integer>itr=hm.keySet().iterator();
		while(itr.hasNext()) {
			int key=(int)itr.next();{
				System.out.println(key +" "+hm.get(key));
				
			}
		}

	}

}
