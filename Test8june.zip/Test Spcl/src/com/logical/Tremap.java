package com.logical;

import java.util.Iterator;
import java.util.TreeMap;

public class Tremap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer, String>tm=new TreeMap<Integer, String>();
		tm.put(1, "Hey");
		tm.put(6, "No");
		tm.put(3, "Yes");
		tm.put(2, "Ok");
		tm.put(1, "Hello");
		Iterator<Integer>itr=tm.keySet().iterator();
		while(itr.hasNext()) {
			int key=(int)itr.next();
			System.out.println(key +" "+tm.get(key));
			
		}

	}

}
