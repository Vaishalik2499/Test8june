package com.logical;

public class ArrayAnOddPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,11,12,13,14,15};
		int sum=0;
		for (int i = 1; i < a.length; i=i+2) {
			System.out.println(a[i]);
			sum=sum+a[i];
			
			
		}
		System.out.print("Sum="+sum);

	}

}
