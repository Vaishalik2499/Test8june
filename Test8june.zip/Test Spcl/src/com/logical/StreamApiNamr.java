package com.logical;

import java.util.stream.Stream;

public class StreamApiNamr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stream<String>str=Stream.of("Vaishali","Kolhe","Geeta");
		str.forEach(System.out::println);

	}

}
