package com.Questionnum2;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


//Write a program that accepts an email string and validates that email. If email is valid must display success message and If email is not valid must display error message
//Example:  Input - test01*gmail.com
//	     Output - Invalid Email Id
//	     Input - student01@gmail.com
//	     Output - Valid Email Id

public class EmailValidator {
	public static boolean vemail(String email) {
		String regex="^[A-Za-z0-9+-]+@[A-Za-z0-9.-]+$";
		
		Pattern pattern=Pattern.compile(regex);
		
		Matcher matcher=pattern.matcher(email);
		
		
		return matcher.matches() ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String email="test01 gmail.com";
		boolean isValid=vemail(email);
		if(isValid) {
			System.out.println("Valid email Id");
		}
		else {
			System.out.println("For 1st ="+" InValid email Id");
		}
		email="student01@gmail.com";
		isValid=vemail(email);
		if(isValid) {
			System.out.println("Valid email id");
		}
		else {
			System.out.println("InValid email id");
		}

	}

}
