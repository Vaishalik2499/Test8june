package com.Questionnum2;

public class B {
	int lastdigit1;
	int lastdigit2;
	
	public B(A input) {
		lastdigit1=input.getNumber1()%10;
		lastdigit2=input.getNumber2()%10;
	}
	public int getLastdigit1() {
		
		return lastdigit1;
		
	}

public int getLastdigit2() {
		
		return lastdigit2;
		
	}

}
