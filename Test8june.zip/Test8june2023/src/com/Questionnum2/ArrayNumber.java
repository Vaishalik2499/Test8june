package com.Questionnum2;

import java.util.List;

//Find the maximum number in a jagged array of numbers or array of numbers.
//Input: [2, 4, 10, [12, 4, [100, 99], 4], [3, 2, 99], 0]

public class ArrayNumber {
	
	public static int findmax(List<Object>arr) {
		int max=Integer.MIN_VALUE;
		
		for(Object obj:arr)
		
		 {
			if(obj instanceof List<?>) {
				int innermax=findmax((List<Object>)obj);
				
				
				if(innermax>max) {
					max=innermax;
				}
			}
			else {
				int num=(int)obj;
				if(num>max) {
					max=num;
				}
			}
		}
		
		return max;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		List<Object>input= List.of(2,4,10, List.of(12,4, List.of(100,99),4) ,List.of (3,2,99),0);
		int max=findmax(input);
		System.out.println(max);
		
	}

}
