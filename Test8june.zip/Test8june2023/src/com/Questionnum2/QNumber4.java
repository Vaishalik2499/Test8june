package com.Questionnum2;
//Create a class that accepts two numbers. Create another class that fetches the last digit of those two numbers. Create a third class that multiplayer that last two digits.
//Example: Class A: Accept two numbers.
//Class B: Fetches the last digits of the numbers
//Class C: Multiplay the last two digits.


public class QNumber4 {

	public static void main(String[] args) {
		A input=new A(25,47);
		
		
		B b =new B(input);
		int lastdigit1=b.getLastdigit1();
		int lastdigit2=b.getLastdigit2();
		
		System.out.println("Last digit="+ lastdigit1 +"Lastdigit 2= "+ lastdigit2);
		
		C c=new C(b);
		int result=c.getresult();
		System.out.println("Multi="+result);
		
		

	}

}
