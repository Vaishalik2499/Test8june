package com.Questionnum2;

public class C {
	int result;
	
	public C(B input) {
		result=input.getLastdigit1();
		result=input.getLastdigit2();
	}
	public int getresult() {
		return result;
		
	}

}
