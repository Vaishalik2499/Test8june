package com.jbk.Demo.IOC.Spring.Boot.Annotation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoIocSpringBootAnnotationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoIocSpringBootAnnotationApplication.class, args);
		System.out.println("IOC SpringBoot Working....");
	}
	
	@Bean("m1")
	public Customer getName() {
		System.out.println("explicitely Bean");
		Customer c=new Customer();
		
		c.CustomerId=100;
		c.getCustomername();
		return c;
		
	}

	@Bean("m2")
	public Customer getName2() {
		System.out.println("explicitely bean ");
		Customer c=new Customer();
		
		c.CustomerId=101;
		c.getCustomername();
		return c;
		
	}

}
