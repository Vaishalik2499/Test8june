package com.jbk.Demo.IOC.Spring.Boot.Annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MerchantController {
	
	@Autowired
	@Qualifier("m2")
	Customer c;
	@Value("${merchantId}")
	int merchantId;
	
	@RequestMapping("IOCTest")
	public Customer name() {
		
		System.out.println(merchantId);
		
		
		c.getCustomername();
		
		return c;
		
	}

}
