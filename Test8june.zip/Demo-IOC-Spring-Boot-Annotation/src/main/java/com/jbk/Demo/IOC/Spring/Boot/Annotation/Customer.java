package com.jbk.Demo.IOC.Spring.Boot.Annotation;

import org.springframework.stereotype.Component;

//@Component
public class Customer {
	int CustomerId;
	
	public String getCustomername() {
		
		System.out.println("I am Customer");
		System.out.println(CustomerId);
		return "JAVABYKIRAN";
		
	}

}
