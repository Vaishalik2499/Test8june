package com.jbk.Demo.IOC.Spring.Boot.Annotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoIocSpringBootAnnotationApplicationTests {

	@Test
	void contextLoads() {
	}

}
