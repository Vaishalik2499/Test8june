package com.jbk.DemoSpringBootAOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootAopApplicationTests {

	@Test
	void contextLoads() {
	}

}
