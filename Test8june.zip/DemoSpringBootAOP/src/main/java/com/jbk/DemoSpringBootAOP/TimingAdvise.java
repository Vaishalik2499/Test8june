package com.jbk.DemoSpringBootAOP;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class TimingAdvise {
	
	@Before("execution(* com.jbk.DemoSpringBootAOP.StudentController.welcome())")
	public void greetingName() {
		System.out.println("Hello");
      System.out.println("I am getcalled before any of method..." + new java.util.Date());
		
		
	}
	@After("execution(* com.jbk.DemoSpringBootAOP.StudentController.welcome())")
	public void greetingName2() {
		System.out.println("Bye..");
		

}
	@Around("execution(* com.jbk.DemoSpringBootAOP.StudentController.welcome())")
	public void arround() {
		System.out.println("Good Bye..");
}
}