package com.jbk.DemoSpringBootAOP;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	@RequestMapping("TestAop")
	public String welcome()
	{
		System.out.println("SpringBoot AOP....");
		return "SpringBoot AOP";
		
	}
}
