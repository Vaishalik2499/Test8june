package com.Collection;

import java.util.ArrayList;

public class Arraylistwithforeach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<String>();
		al.add("Vaishali");
		al.add("Kisan");
		al.add("Kolhe");
		
		for (String string : al) {
			System.out.println(string);
		}

	}

}
