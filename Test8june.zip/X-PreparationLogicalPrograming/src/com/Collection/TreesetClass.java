package com.Collection;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String>t=new TreeSet<String>();
		t.add("X");
		t.add("P");
		t.add("B");
		
		System.out.println(t);
		Iterator<String>itr=t.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
