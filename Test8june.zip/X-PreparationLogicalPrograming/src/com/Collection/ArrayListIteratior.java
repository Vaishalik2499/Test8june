package com.Collection;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListIteratior {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<String>();
		al.add("Vaishali");
		al.add("Kisan");
		al.add("Kolhe");
		
		ListIterator<String>itr=al.listIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
