package com.Collection;

import java.util.Arrays;
import java.util.List;

public class StreanApiUsed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer>list=Arrays.asList(10,2,18,19,23,25,2,3,7,15,9);
list.stream().filter(n->n%2!=0).forEach(System.out::println);

	}

}
