package com.Collection;

import java.util.stream.Stream;

public class PrintNameUsingStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stream<String>str=Stream.of("Vaishali","Kiya","Ram","Shyam");
		str.forEach(n->System.out.println(n));

	}

}
