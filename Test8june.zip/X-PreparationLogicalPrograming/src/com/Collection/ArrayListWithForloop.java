package com.Collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class ArrayListWithForloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(101);
		al.add(102);
		al.add(109);
		al.add(104);
		
		
		System.out.println(al);
		for (int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i));
			
		}
		
		// Add element on the basis of index
		al.add(2,103);
		System.out.println(al);
		
		//check size of Arraylist
		int size=al.size();
		System.out.println(size);
		
		// Sorting on Arraylist
		Collections.sort(al);
		System.out.println(al);
		
		//delete element from Arraylist
		al.remove(1);
		System.out.println(al);
		
		

	}

}
