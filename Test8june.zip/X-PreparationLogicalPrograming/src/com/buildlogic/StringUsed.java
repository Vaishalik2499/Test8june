package com.buildlogic;

import java.util.Arrays;

public class StringUsed {

	public StringUsed(char[] chararr) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Vaishali";
		String s2="Kolhe";
		
		String c=s1+s2;
		System.out.println(c);
		
		char[]chararr=c.toCharArray();
	
		Arrays.sort(chararr);
		String s=new String(chararr);
		System.out.println(s);
		
		
		

	}

}
