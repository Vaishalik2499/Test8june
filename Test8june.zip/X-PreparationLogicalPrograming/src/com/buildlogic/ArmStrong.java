package com.buildlogic;

public class ArmStrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n=370;
		int temp=n;
		int sum=0;
		
		while(n>0) {
			int v=n%10;
			sum=sum+(v*v*v);
			n=n/10;
		}
		if(sum==temp) {
			System.out.println("Is ArmStrong");
		}
		else {
			System.out.println("Is Not  ArmStrong");
		}
		

	}

}
