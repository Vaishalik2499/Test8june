package com.buildlogic;

import java.util.HashMap;
import java.util.Iterator;

public class HashmapIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String>hm=new HashMap<Integer, String>();
		hm.put(1, "Vaishali");
		hm.put(2, "Shyam");
		hm.put(3, "Vaishali");
		
		Iterator<Integer>itr=hm.keySet().iterator();
		while(itr.hasNext()) {
			int key=(int)itr.next();
			System.out.println(key +" "+ hm.get(key));
		}

	}

}
