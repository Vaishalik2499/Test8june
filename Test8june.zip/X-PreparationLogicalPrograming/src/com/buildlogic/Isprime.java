package com.buildlogic;

public class Isprime {

	public static void main(String[] args) {
		int num=13;
		if(Isprime(num)) {
			System.out.println(num +"Is prime number");
			
		}
		else {
			System.out.println(num +"Is not prime number");
		}
		if(num>9) {
			int temp=num;
			while(temp>0) {
				int digit=temp%10;
				if(Isprime(digit)) {
					System.out.println(digit +"Is prime digit");
				}
				else
				{
					System.out.println(digit +"Is not prime digit");
				}
				temp=temp/10;
				
			}
			
		}

	}

	private static boolean Isprime(int num) {
		if(num<=1) {
			return false;
		}
		for(int i=2;i<=Math.sqrt(num);i++) {
			if(num%i==0) {
				return false;
			}
		}
		
		return true;
	}

}
