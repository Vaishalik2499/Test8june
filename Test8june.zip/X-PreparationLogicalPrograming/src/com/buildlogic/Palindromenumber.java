package com.buildlogic;

public class Palindromenumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=151;
		int temp=n;
		int sum=0;
		while(n>0) {
			int v=n%10;
			sum=(sum*10)+v;
			n=n/10;
		}
		if(sum==temp) {
			System.out.println("Is Palindrome number");
		}
		else {
			System.out.println("Not Palindrome number");
		}

	}

}
