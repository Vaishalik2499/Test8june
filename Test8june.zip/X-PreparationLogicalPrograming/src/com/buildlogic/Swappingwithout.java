package com.buildlogic;

public class Swappingwithout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20;
		int b=30;
		
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println(a +" "+b);

	}

}
