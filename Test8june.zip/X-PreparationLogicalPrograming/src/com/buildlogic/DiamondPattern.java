package com.buildlogic;

public class DiamondPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		
		for(int i=1;i<=n;i++) {
			
			//spaces
			int spaces=n-i;
			for(int j=1;j<=spaces;j++) {
				System.out.print(" ");
			}
			//for star=2*i-1
			int star=2*i-1;
			for(int j=1;j<=star;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		//2nd half
        for(int i=n;i>=1;i--) {
			
			//spaces
			int spaces=n-i;
			for(int j=1;j<=spaces;j++) {
				System.out.print(" ");
			}
			//for star=2*i-1
			int star=2*i-1;
			for(int j=1;j<=star;j++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
