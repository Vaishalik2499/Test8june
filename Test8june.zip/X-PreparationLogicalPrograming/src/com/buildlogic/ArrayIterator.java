package com.buildlogic;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(101);
		al.add(102);
		al.add(103);
		
		Iterator<Integer>itr=al.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
