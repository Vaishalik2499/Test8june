package com.logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringArrayComparison {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String []a= {"Abc","xyz","pqr"};
		String []b= {"xyz","Abc","pqr","mno"};
		List<String>list=new ArrayList<String>(Arrays.asList(a));
		
		for(String s:b) {
			if(!list.contains(s)) {
				list.add(s);
		}
		}
		a=list.toArray(new String[0]);
		System.out.println(Arrays.toString(a));
		
		
	}
}
