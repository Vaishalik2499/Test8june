package com.logical;

public class Isprime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=13;
	if(Isprime(n)) {
		System.out.println(n +"Number is prime");
		
	}
	else {
		System.out.println(n +"Number not is prime");
	}
	if(n>9) {
		int temp=n;
		while(temp>0) {
			int digit=temp%10;
		if(Isprime(digit)) {
			System.out.println(digit +"Digit is prime");
		}
		else
			System.out.println(digit +"Digit not is prime");
		temp=temp/10;
		}
	}
	}

	private static boolean Isprime(int n) {
		if(n<=1) {
			return false;
		}
		for(int i=2;i<=Math.sqrt(n);i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}

}
