package com.logical;

public class Findoddpositionelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,11,12,13,14,15,16};
		int sum=0;
		for(int i=1;i<a.length;i=i+2) {
			System.err.println(a[i]);
			sum=sum+a[i];
		}
		System.out.println(sum);

	}

}
