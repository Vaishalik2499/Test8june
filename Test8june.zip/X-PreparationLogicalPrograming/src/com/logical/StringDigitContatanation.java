package com.logical;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StringDigitContatanation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   String str1 = "abc123xyz";
	        String str2 = "def456uvw";

	        String concatenated = concatenateStrings(str1, str2);
	        System.out.println("Concatenated String: " + concatenated);
	    }
   

    private static String concatenateStrings(String str1, String str2) {
        List<Character> digits = new ArrayList<>();
        List<Character> characters = new ArrayList<>();

        for (char c : str1.toCharArray()) {
            if (Character.isDigit(c)) {
                digits.add(c);
            } else {
                characters.add(c);
            }
        }

        for (char c : str2.toCharArray()) {
            if (Character.isDigit(c)) {
                digits.add(c);
            } else {
                characters.add(c);
            }
        }

        Collections.sort(digits);
        Collections.sort(characters);

        StringBuilder result = new StringBuilder();
        for (char c : characters) {
            result.append(c);
        }
        System.out.println();

        for (char c : digits) {
            result.append(c);
        }

        return result.toString();
    }
}
