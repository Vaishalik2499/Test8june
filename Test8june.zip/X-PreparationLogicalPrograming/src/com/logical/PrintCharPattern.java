package com.logical;

public class PrintCharPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=7;
		
		for(int i=n;i>=1;i--) {
			char ch='A';
			for(int j=1;j<=i;j++) {
				System.out.print(ch +" ");
				ch++;
			}
			System.out.println();
		}

	}

}
