package com.logical;

import java.util.Iterator;

public class Bubblesort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,8,2,7,3,1,89,15,4,5,9};
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]>a[j]){
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
				
			}
			
			
		}
		//System.out.println(a[a.length-1]);
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
			
		}
		

	}

}
