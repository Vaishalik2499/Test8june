package com.logical;

import java.util.HashMap;
import java.util.Map;

public class HashmApEMpIdNAMeSepe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, String>emp=new HashMap<Integer, String>();
		emp.put(1, "Vaishali");
		emp.put(2, "Kisan");
		emp.put(3, "Kolhe");
		
		System.out.println("EmpId");
		for(int empid:emp.keySet()) {
			System.out.println(empid);
		}
		System.out.println("EmpName=");
		for(String empname:emp.values()) {
			System.out.println(empname);
		}

	}

}
