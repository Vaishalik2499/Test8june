package com.logical;

public class StringPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Nayan";
		boolean flag=true;
		
		 s=s.toLowerCase();
		 
		 for(int i=0;i<s.length()/2;i++) {
			 if(s.charAt(i)!=s.charAt(s.length()-i-1)) {
				 flag=false;
				 break;
			 }
			 
		 }
		 if(flag) {
			 System.out.println("String Palindrom");
		 }
		 else {
			 System.out.println("String not Palindrome");
		 }

	}

}
