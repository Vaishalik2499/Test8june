package com.logical;

import java.util.Arrays;

public class StringArraySortAndConcate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="xyz";
		String s2="pqr";
		
		String combin=s1+s2;
		char[]chararray=combin.toCharArray();
		Arrays.sort(chararray);
		
		String s=new String(chararray);
		System.out.println(s);

	}

}
