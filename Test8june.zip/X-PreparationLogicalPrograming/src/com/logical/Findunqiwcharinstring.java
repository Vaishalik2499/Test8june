package com.logical;

import java.util.HashMap;
import java.util.Map;

public class Findunqiwcharinstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     String s = "Hello, World!";

	        char firstUniqueChar = findFirstUniqueChar(s);

	        if (firstUniqueChar != '\0') {
	            System.out.println("The first unique character is: " + firstUniqueChar);
	        } else {
	            System.out.println("No unique character found.");
	        }
	    }

	    public static char findFirstUniqueChar(String s) {
	        Map<Character, Integer> charCounts = new HashMap<>();

	        // Count the occurrences of each character
	        for (char c : s.toCharArray()) {
	            charCounts.put(c, charCounts.getOrDefault(c, 0) + 1);
	        }

	        // Find the first unique character
	        for (char c : s.toCharArray()) {
	            if (charCounts.get(c) == 1) {
	                return c;
	            }
	        }

	        return '\0'; // No unique character found
	    }
	}

