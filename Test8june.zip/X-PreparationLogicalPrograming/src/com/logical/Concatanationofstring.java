package com.logical;

import java.util.Arrays;

public class Concatanationofstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="xyz";
		String s1="mno";
		
		String combin=s+s1;
		
		char[]arr=combin.toCharArray();
		Arrays.sort(arr);
		String str=new String(arr);
		
		System.out.println(str);

	}

}
