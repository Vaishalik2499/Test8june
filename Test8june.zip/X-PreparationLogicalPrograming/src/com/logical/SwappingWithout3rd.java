package com.logical;

public class SwappingWithout3rd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20;
		int b=30;
		System.out.println("Before Swapping "+ a+ " "+ b);

		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After Swapping "+ a+ " "+ b);

	}

}
