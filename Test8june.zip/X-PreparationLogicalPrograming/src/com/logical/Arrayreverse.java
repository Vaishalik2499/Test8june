package com.logical;

public class Arrayreverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {5,6,7,8,9,10};
		for(int i=a.length-1;i>=0;i--) {
			System.out.println(a[i]);
		}

	}

}
