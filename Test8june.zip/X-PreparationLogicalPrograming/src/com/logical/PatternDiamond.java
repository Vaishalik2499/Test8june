package com.logical;

public class PatternDiamond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;    
		for(int i=1;i<=n;i++) { 
			 	//Space n-i
			int space=n-i;
			for(int j=1;j<=space;j++) {
				System.out.print(" ");
			}
			//Star 2*i-1;    // i=1 ... star =1 
			// i=2    star= 2*2-1=3
			//i=3    star=2*3-1=5
			int star=2*i-1;
			for(int j=1;j<=star;j++) {
				System.out.print("*");
			}
			System.out.println();
			}
		// 2nd half reverse 
		for(int i=n;i>=1;i--) { 
			 //Space n-i
			int space=n-i;
			for(int j=1;j<=space;j++) {
				System.out.print(" ");
			}
			//Star 2*i-1;    // i=1 ... star =1 
			// i=2    star= 2*2-1=3
			//i=3    star=2*3-1=5
			
			int star=2*i-1;
			for(int j=1;j<=star;j++) {
				System.out.print("*");
			}
			System.out.println();
			
		}
		

	}

}
