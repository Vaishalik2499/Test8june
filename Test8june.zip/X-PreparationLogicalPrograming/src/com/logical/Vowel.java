package com.logical;

public class Vowel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="My name is vaishali";
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)=='a'||s.charAt(i)=='i'||s.charAt(i)=='e'||s.charAt(i)=='o'||s.charAt(i)=='u') {
				System.out.println("Vowel"+s.charAt(i));
			}
			else {
				System.out.println("Constra "+ s.charAt(i));
			}
			
		}

	}

}
