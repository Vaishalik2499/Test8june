package com.logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FindCommonElementStringArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String[] s1 = {"Java", "By", "Kiran", "for", "IT-NonIT"};
	        String[] s2 = {"Java", "Experienced", "By"};
	        
	       List<String>CommonElement=FindCommnelement(s1,s2);
	       System.out.println("Commonelement="+CommonElement);
	       
	}

	private static List<String> FindCommnelement(String[] s1, String[] s2) {
		List<String>CommonElement=new ArrayList<String>();
		List<String>list1=Arrays.asList(s1);
		List<String>list2=Arrays.asList(s2);
		
		for(String element:list1) {
			if(list2.contains(element)) {
				CommonElement.add(element);
			}
		}


		
		
		
		return CommonElement;
	}

}
