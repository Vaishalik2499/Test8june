package com.logical;

public class PatternButterfly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		
		for(int i=1;i<=n;i++) {
			//First upper part
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			// spaces 2*(n-i)
			int  spaces=2*(n-i);
			for(int j=1;j<=spaces;j++) {
				System.out.print(" ");
			}
			//2nd upper part
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		// 2nd part
		
		for(int i=n;i>=1;i--) {
			//First upper part
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			// spaces 2*(n-i)
			int  spaces=2*(n-i);
			for(int j=1;j<=spaces;j++) {
				System.out.print(" ");
			}
			//2nd upper part
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		

	}

}
