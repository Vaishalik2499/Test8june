package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Insertrecord {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		Statement stmt=con.createStatement();
		System.out.println("Connected");
		
	//	stmt.executeUpdate("insert into customer values (203,'Vaishu','Shegaon')");
       stmt.executeUpdate("insert into customer values (204,'Shyam','Janori')");
       stmt.executeUpdate("insert into customer values (205,'Mahesh','Buldana')");
		System.out.println("Record inserted");
				

	}

}
