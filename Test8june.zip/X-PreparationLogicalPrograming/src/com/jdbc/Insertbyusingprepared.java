package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Insertbyusingprepared {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		//Statement stmt=con.createStatement();
		System.out.println("Connected");
		PreparedStatement pstmt=con.prepareStatement("insert into customer(id,name,city)values(?,?,?)");
		
		pstmt.setInt(1, 55);
		pstmt.setString(2, "Vaishuk");
		pstmt.setString(3, "PunetpShegaon");
		pstmt.executeUpdate();
		System.out.println("Inserted");
		
		

	}

}
