package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Update {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		Statement stmt=con.createStatement();
		System.out.println("Connected");
		
		//Statement stmt=con.createStatement();
		//stmt.executeUpdate("update customer set city='mumbai' where id=1");
		//System.out.println("Record updated");
		stmt.executeUpdate("Update customer set city ='dhule' where id=1");
		System.out.println("Record updated");
		
		stmt.executeUpdate("delete from customer where id=1 ");
		System.out.println("Record deleted");
		

	}

}
