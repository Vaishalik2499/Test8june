package com.jbk.Demo.MVC.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMvcProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
