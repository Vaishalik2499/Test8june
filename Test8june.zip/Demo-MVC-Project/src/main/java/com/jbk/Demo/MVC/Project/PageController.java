package com.jbk.Demo.MVC.Project;

import org.hibernate.Session;


import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class PageController {
	@Autowired
	SessionFactory sf;
	@RequestMapping("/")
	public String loginpage() {
		return "login";
	}
	
	@RequestMapping("/login")
	public String login(@ModelAttribute Login login, Model model) {
		Session session=sf.openSession();
		
		Login dblogin=session.get(Login.class, login.getUsername());
		String page="login";
		String msg=null;
		  if(dblogin !=null) {
			if(login.getPassword().equals(dblogin.getPassword())) {
				page="home";
			}else {
				msg="invalid password";
			}
			}
		else {
			msg="invalid username and password";
		}
		model.addAttribute("msg", msg);
		return page;
	}
	@RequestMapping("/service")
	public String service() {
		return "service";
	}
	@RequestMapping("/about")
	public String about() {
		return "about";
	}
@RequestMapping("/contactpage")
	public String contactpage() {
		return "contact";
	}
	
	@RequestMapping("/contact")
	public String contact(@ModelAttribute Contact contact,Model model) {
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.save(contact);
		tx.commit();
		return null;
	}
	
	@RequestMapping("/homepage")
	public String homepage() {
		return "home";
	}
	
	@RequestMapping("/signuppage")
	public String signup() {
		return "signup";
	}
	
	@RequestMapping("/signup")
	public String signup(@ModelAttribute Login login,Model model) {
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.save(login);
		tx.commit();
		return null;
	}
	

	@RequestMapping("/logout")
	public String logout() {
		return "login";
	}

}
