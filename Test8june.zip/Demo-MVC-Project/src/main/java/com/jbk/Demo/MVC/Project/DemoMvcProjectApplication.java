package com.jbk.Demo.MVC.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan("com")
public class DemoMvcProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvcProjectApplication.class, args);
		System.out.println("Hello SpringBoot Mvc");
	}

}
