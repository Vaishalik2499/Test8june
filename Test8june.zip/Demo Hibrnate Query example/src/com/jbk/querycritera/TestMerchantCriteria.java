package com.jbk.querycritera;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class TestMerchantCriteria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(Merchant.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		
		Criteria criteria=ss.createCriteria(Merchant.class);
		criteria.add(Restrictions.eq("city", "pune"));
		List<Merchant>list=criteria.list();
		//System.out.println(list);
		for (Merchant merchant : list) {
			System.out.println(merchant.getCity());
			
		}
		

	}

}
