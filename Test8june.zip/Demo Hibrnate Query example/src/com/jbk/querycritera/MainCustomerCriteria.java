package com.jbk.querycritera;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class MainCustomerCriteria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(Customer.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		

		Criteria criteria=ss.createCriteria(Customer.class);
		List<Customer>list=criteria.list();
		for (Customer customer : list) {
			System.out.println(customer);
			

			Criteria criteria2=ss.createCriteria(Customer.class);
			criteria2.add(Restrictions.eq("city", "pune"));
			List<Customer>list2=criteria2.list();
			for (Customer customer2 : list2) {
				System.out.println(customer2.getCity());
				
			
			
			
			}
			
		}
	}
}

