package com.jbk.querycritera;


import java.util.List;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class MainCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration ();
		cfg.addAnnotatedClass(Customer.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		//Transaction tx=ss.beginTransaction();
		
		Query<Customer>query=ss.createQuery("from Customer");
		List<Customer>list=query.list();
	//	System.out.println(list);
		
		for (Customer customer : list) {
			System.out.println(customer);
			
		}
		
	   sf.close();

	}

}
