package com.jbk.querycritera;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestMerchantQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration ();
		cfg.addAnnotatedClass(Merchant.class).configure("test.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		
		
		Query<Merchant>query=ss.createQuery("from Merchant");
		List<Merchant>list=query.list();
		//System.out.println(list);
		for (Merchant merchant : list) {
			System.out.println(merchant);
			
		}


	}

}
