package com.jbk;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class LoadMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(Employee.class).configure("test.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		//single record show by get() and load()
		//Employee emp = ss.load(Employee.class, 2); //primary id
		Employee emp=ss.get(Employee.class, 2);
	
		
		System.out.println(emp.getId());
		System.out.println(emp.getName());

		System.out.println(emp.getPhone());

	
	}
	

}
