package com.jbk;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestEmployee {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(Employee.class).configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		Employee emp = new Employee(4, "Rajesh","992990009");
		
		//ss.save(emp);
		//ss.update(emp);
		ss.delete(emp);
		
		
		tt.commit();
		ss.close();
		//System.out.println("Record inserted.."+ emp);

		//System.out.println("Record Updated.."+ emp);

		System.out.println("Record Deleted.."+ emp);
}
}